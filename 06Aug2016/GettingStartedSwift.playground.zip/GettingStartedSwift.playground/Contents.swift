//: Playground - noun: a place where people can play

import UIKit

//Basics: variables and constants can be named anything. Even unicode characters
//modify let and var
//semi-colon is optional

var 🐶🐮 = "dogcow"
🐶🐮 = "dog"
let number = 123
print("🐶🐮")
print("Hi \(🐶🐮)") //String interpolation
print("Hi" + "World" + 🐶🐮)

//Type alias:
public typealias Index = Int
var locations: [Index]


//---------------------------------------------------------------------------

//Tuples:  group multiple values into a single compound value.
//Values can be any type and do not have to be of the same type.

//let square = ("black", 5)
//Can name the elements of the tuple as well and then access it with the same names.
let square = (squareColor: "black", sideLength: 5)
print("\(square.squareColor)")

//Decomposing a tuple:
let (squareColor, sideLength) = square
print("Square is of color \(squareColor)")

//Can also use index numbers instead of tuple names
print("Square is of color \(square.0)")

//Can omit tuple values too using ‘_’
let (_, justTheSideLength) = square
print("SideLength of sqaure \(justTheSideLength)")
//Particularly useful as the return values of functions.


//Tuples as return types from functions
func details(_ array: [Int]) -> (min: Int, max: Int) {
    var min = array[0]
    var max = array[0]
    for number in array {
        min = min < number ? min : number
        max = max > number ? max : number
    }
    return (min, max)
}
let marks = details([1,2,3,4,5])
print(marks.0) //accessing tuple through index value
let (_, max) = details([1,2,3,4,5]) //exhibits decomposing and ignoring of tuples
print(max)

//---------------------------------------------------------------------------

//Classes and structures

struct Resolution {
    var width = 0
    var heigth = 0
}

class VideoMode {
    var resolution = Resolution()
    var name: String?
}

var someResolution = Resolution()
var someResolution2 = someResolution
let someVideoMode = VideoMode()
var someVideoMode2 = someVideoMode

someVideoMode.resolution.width = 1280
print("The width of someVideoMode is now \(someVideoMode.resolution.width)")

print("The width of someVideoMode2 is now \(someVideoMode2.resolution.width)") //Shows that Classes are reference types.

print("The width of someResolution2 is now \(someResolution2.width)")

someResolution.width = 2048
print("The width of someResolution is now \(someResolution.width)")

print("The width of someResolution2 is now \(someResolution2.width)") //Shows that structs are value types.

//---------------------------------------------------------------------------

//Enumerations: Group of related values.

enum Direction {
    case north, south, east, west
}
var currentDirection = Direction.west
let rememberedDirection = currentDirection
currentDirection = .east
if rememberedDirection == .west {
    print("The remembered direction is still .west")
} // Prints "The remembered direction is still .west"




//---------------------------------------------------------------------------

//Switch

let score = 99

switch score {
    case 0..<35:                       //Matching a range
    print("No worries. Try harder.")
    case 35:
    print("Yay! Managed to pass.")     //explicit break not required
    case 36...95 where score < 75:     //where in switch
    print("First class")
    case 99, 100:                      //Matching multiple values
    print("That is extraordinary")
    case 36...95 where score > 75:     //where in switch
    print("Distinction")
    default:
    print("Invalid score")
}

//---------------------------------------------------------------------------------------

//Subscripts: shortcuts to retrieve values from a collection or sequence. Can be defined on classes, structs or enums

class Roles {
    private var roles = ["Manager", "Coder", "Designer"]
    
    subscript(index: Int) -> String {
        get {
            return roles[index]
        }
        set(newValue) {
            self.roles[index] = newValue
        }
    }
}

var p = Roles()
print(p[1])
p[0] = "Tester"
print(p[0])

//--------------------------------------------------------------------------------------


// Optionals , Optional binding and Chaining
    //nil coalescing operator
var rateOfInterest: Double?
var defaultRateOfInterest = 5.0
var interest = rateOfInterest ?? defaultRateOfInterest   //nil coalescing operator

rateOfInterest = 7.5
print(rateOfInterest)

//optional binding - if let 

if let rateOfInterest = rateOfInterest {
    print(rateOfInterest)
}



//Optional Chaining
class Person {
    var vehicle: Vehicle?    //optional variable
    var name: String
    init(name: String) {
        self.name = name
    }
}

class Vehicle {
    var model: String = "BMW"

}

var person = Person(name: "Ram")
let bmw = Vehicle()
person.vehicle = bmw
if let vehicleModel = person.vehicle?.model  {    //Optional chaining. Can be multiple chaining as well.
    print("Your vehicle \(vehicleModel) is due for service")
} else {
    print("Exclusive offers to buy new cars")
}

//---------------------------------------------------------------------------

//Guards

func getVoterDetails(name: String, age: Int?) -> String {
    //Using plain 'if'
     if (age == nil || age < 18) {
         return ("Age \(age!) is invalid")
     }
     //Do something
     return "Found the details of \(name) with \(age!)"
    
    //Using if let
    // if let age = age where age >= 18 {
    //     // long way to go before return
    //     return "Found the details of \(name) with \(age)"
    // }
    //  return ("Age \(age) is invalid")
    
    //Using guards.
//    guard let age = age where age >= 18 else {
//        return ("Age is invalid")
//    }
 //   //Do all that you want
 //   return "Found the details of \(name) with \(age)"
}

print(getVoterDetails(name: "John", age: 18) )

//---------------------------------------------------------------------------

//Functions

//Functions with argument labels: espressive, sentence like, clear.

func greet(_ person: String,from place: String) {
    print("Welcome to \(person) from \(place)")
}

greet("Modi",from: "Gujarat")





//Variadic parameters
func sum(_ numbers: Int... ) -> Int {
    var sum = 0
    for number in numbers {
        sum = sum + number
    }
    return sum
}

print(sum(1, 2, 3, 4, 5))

//multiple parameters an be passed too.
func sample(name: String, startingValue:Int, additionalValue:Int = 77, values:Int...) -> Int {
    var total:Int = startingValue + additionalValue
    for v in values {
        total += v
    }
    
    return total
}
sample(name: "hi", startingValue: 0, additionalValue: 50, values: 1,2,3,4,5)

//Function types: Comprises of the parameter names and the return type:
//(Int, Int) -> Int


func addTwoInts(a: Int, b: Int) -> Int {
   return a + b
}

//Using function types

let mathFunction: (Int, Int) -> Int = addTwoInts
print(mathFunction(2,3))

//Function types as parameter types

func printMathResult(_ mathFunction: (Int, Int) -> Int, _ a: Int, _ b: Int) {
    print("Result: \(mathFunction(a, b))")
}
printMathResult(addTwoInts, 3, 5)
// Prints "Result: 8"

//Function types are return types
func stepForward1(input: Int) -> Int {
    return input + 1
}
func stepBackward1(input: Int) -> Int {
    return input - 1
}

func chooseStepFunction1(backward: Bool) -> (Int) -> Int {
    return backward ? stepBackward1 : stepForward1
}

let result1 = chooseStepFunction1(backward: true)
print(result1(3))

//Nested Functions

func chooseStepFunction(backward: Bool) -> (Int) -> Int {
    func stepForward(input: Int) -> Int {
        return input + 1
    }
    func stepBackward(input: Int) -> Int {
        return input - 1
    }
    return backward ? stepBackward : stepForward
}


let result = chooseStepFunction1(backward: false)
print(result(3))

//-------------------------------------------------------------------------------------

//Closures


// a closure that has 1 parameter and no return type
var hello = { (s: String) in
    print("Hi \(s)")
}

print(hello("everyone"))

//Closure with parameters and return type.
var divide = {(value1: Int, value2: Int) -> Int in
   return value1/value2
}

var dividedOutput = divide(200, 20)
print(dividedOutput)

//Closures with filters

var numbers = [1, 2, 3, 4, 5, 6, 7, 8]

var evenNumbers = numbers.filter { $0 % 2 == 0 }
print(evenNumbers)
// evenNumbers = [2, 4, 6, 8]

//Or remove all the even numbers:

var oddNumbers = numbers.filter { $0 % 2 == 1 }
print(oddNumbers)
// oddNumbers = [1, 3, 5, 7]

//Capturing values:


func incrementer(increment: Int) -> () -> Int {
    var total = 0
    
    let result = { () -> Int in
        total += increment
        return total
    }
   
    return result
}

var doIncrement = incrementer(increment: 10)
doIncrement()
doIncrement()


//--------------------------------------------------------------------------------------

// Generics

func swap<T>(_ a: inout T, _ b: inout T) {
    let temporaryA = a
    a = b
    b = temporaryA
}

var a = "Hey"; var b = "there"
swapTwoInts(&a, &b)
print(a)
print(b)

//---------------------------------------------------------------------------------------

//Extensions

extension Int {
    var add: Int {return self + 100 }
    var sub: Int { return self - 10 }
    var mul: Int { return self * 10 }
    var div: Int { return self / 5 }
}

let addition = 3.add
print("Addition is \(addition)")

let subtraction = 120.sub
print("Subtraction is \(subtraction)")

let multiplication = 39.mul
print("Multiplication is \(multiplication)")

let division = 55.div
print("Division is \(division)")

let mix = 30.add + 34.sub
print("Mixed Type is \(mix)")














